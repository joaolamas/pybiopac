# pybiopac


[pybiopac](https://github.com/joaolamas/pybiopac)
for Python.

`pybiopac` is compatible with Python 3.

<!-- TOC -->

## Installation

# Todo

```bash
pip install pybiopac
```

Or install the development version from GitHub:

```bash
pip install git+https://github.com/jplamas/pybiopac
```

## Usage

```python
>>> import pybiopac as b
>>> b.pybiopac()

```

## Documentation

You can [read the documentation online](https://www.biopac.com/wp-content/uploads/AcqKnowledge-5-Software-Guide.pdf).
Chapter 21. Page 482 to 495


## Functions and examples

### Connection

Todo

### Test in while loop data reading

Pull requests are welcome!

## Contributors

- João Lamas ([jlamas](https://github.com/jplamas))
